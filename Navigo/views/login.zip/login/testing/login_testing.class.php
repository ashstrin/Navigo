<?php

class testing{
    public function display(){
        ?>
<html>
    <head></head>
    <body>
        <h3>Here is <strong>testing</strong>.</h3>
    </body>
</html>
<?php
    }
}

